<?php

namespace ow;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\BatSound;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\tile\Sign;
use pocketmine\utils\TextFormat;
use pocketmine\utils\TextFormat as F;
use pocketmine\level\particle\AngryVillagerParticle;
use pocketmine\level\particle\WaterDripParticle;
use pocketmine\entity\Effect;
use pocketmine\block\Block;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\utils\Config;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\ItemBreakParticle;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerToggleSprintEvent;

class owstat extends PluginBase implements Listener {
	private $mysqli;
	public $breaks;
	public $place;
	public $kills;
	public $deaths;
	public $joins;
	public $message;
	
	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->mysqli = new \mysqli("127.0.0.1", "юзер", "пароль", "бд");
	}
	
	public function onJoin(PlayerJoinEvent $e) {
		$p = $e->getPlayer();
		$username = strtolower($p->getName());
		$this->updateVariables($username);
		$this->addJoins($username, 1);
	}
	
	public function onQuit(PlayerQuitEvent $e) {
		$p = $e->getPlayer();
		$username = strtolower($p->getName());
		$this->save($username);
	}
	
	public function onBreaks(BlockBreakEvent $e) {
		$p = $e->getPlayer();
		$username = strtolower($p->getName());
		$this->addBreaks($username, 1);
	}
	
	public function onPlace(BlockPlaceEvent $e) {
		$p = $e->getPlayer();
		$username = strtolower($p->getName());
		$this->addPlace($username, 1);
	}
	
    public function PlayerDeath(PlayerDeathEvent $e){
        $entity = $e->getEntity();
		$username = strtolower($entity->getName());
        $cause = $entity->getLastDamageCause();
		$this->addDeaths($username, 1);
		if($cause instanceof EntityDamageByEntityEvent) {
			$killer = $cause->getDamager()->getPlayer();
			$kname = strtolower($killer->getName());
			$this->addKills($kname, 1);
		}
    }
	
	/** часть, отвечающая за установку переменных **/
	
	public function updateVariables($username) {
		$username = strtolower($username);
		$data = $this->getData($username);
		
		$this->breaks[$username] = $data['break'];
		$this->place[$username] = $data['place'];
		$this->kills[$username] = $data['kills'];
		$this->deaths[$username] = $data['deaths'];
		$this->joins[$username] = $data['joins'];
		$this->messages[$username] = $data['messages'];
	}
	
	/** часть, ответственная за возвращение данных **/
	
	public function getBreaks($username) {
		$username = strtolower($username);
		return $this->breaks[$username];
	}
	
	public function getPlace($username) {
		$username = strtolower($username);
		return $this->place[$username];
	}
	
	public function getKills($username) {
		$username = strtolower($username);
		return $this->kills[$username];
	}
	
	public function getDeaths($username) {
		$username = strtolower($username);
		return $this->deaths[$username];
	}
	
	public function getJoins($username) {
		$username = strtolower($username);
		return $this->joins[$username];
	}
	
	public function getMessage($username) {
		$username = strtolower($username);
		return $this->message[$username];
	}
	
	/** Часть, отвественная за добавление данных **/
	
	public function addBreaks($username, $value) {
		$username = strtolower($username);
		$this->breaks[$username] += $value;
	}
	
	public function addPlace($username, $value) {
		$username = strtolower($username);
		$this->place[$username] += $value;
	}
	
	public function addKills($username, $value) {
		$username = strtolower($username);
		$this->kills[$username] += $value;
	}
	
	public function addDeaths($username, $value) {
		$username = strtolower($username);
		$this->deaths[$username] += $value;
	}
	
	public function addJoins($username, $value) {
		$username = strtolower($username);
		$this->joins[$username] += $value;
	}
	
	public function addMessage($username, $value) {
		$username = strtolower($username);
		$this->message[$username] += $value;
	}
	
	
	/** часть, отвечающая за mysql бд **/
	
	public function checkAcc($username) {
	    $username = strtolower($username);
		$result = $this->mysqli->query("SELECT * FROM `stat` WHERE `nickname` = '".$username."'");
        $user = mysqli_fetch_assoc($result);
        if($user) {
	        return true;
        } else {
	        return false;
        }
	}
	
	public function createData($username) {
	    $username = strtolower($username);
        if(!$this->checkAcc($username)) {
            $this->mysqli->query("INSERT INTO `stat` (`id`, `nickname`, `break`, `place`, `kills`, `deaths`, `joins`, `messages`) VALUES (NULL, '".$username."', '0', '0', '0', '0', '0', '0')");
		}
	}
	
	public function getData($username) {
	    $username = strtolower($username);
        $result = $this->mysqli->query("SELECT * FROM `stat` WHERE `nickname` = '".$username."'");
		if($this->checkAcc($username)) {
			$data = $result->fetch_assoc();
			$result->free();

			$array = array();
			$array['break'] = $data['break'];
			$array['place'] = $data['place'];
			$array['kills'] = $data['kills'];
			$array['deaths'] = $data['deaths'];
			$array['joins'] = $data['joins'];
			$array['messages'] = $data['messages'];
			
			return $array;
		} else {
		    $this->createData($username);
			$data = $result->fetch_assoc();
			$result->free();

			$array = array();
			$array['break'] = $data['break'];
			$array['place'] = $data['place'];
			$array['kills'] = $data['kills'];
			$array['deaths'] = $data['deaths'];
			$array['joins'] = $data['joins'];
			$array['messages'] = $data['messages'];
			
			return $array;
		}
	}
	
	public function save($username) {
	    $username = strtolower($username);
        if($this->checkAcc($username)) {
			$breaks = $this->getBreaks($username);
			$place = $this->getPlace($username);
			$kills = $this->getKills($username);
			$deaths = $this->getDeaths($username);
			$joins = $this->getJoins($username);
			$message = $this->getMessage($username);
			
            $this->mysqli->query("UPDATE `stat` SET `break` = '".$breaks."', `place` = '".$place."', `kills` = '".$kills."', `deaths` = '".$deaths."', `joins` = '".$joins."', `messages` = '".$message."' WHERE `nickname` = '".$username."'");
		} else {
		    $this->createData($username);
			$breaks = $this->getBreaks($username);
			$place = $this->getPlace($username);
			$kills = $this->getKills($username);
			$deaths = $this->getDeaths($username);
			$joins = $this->getJoins($username);
			$message = $this->getMessage($username);
			
			$this->mysqli->query("UPDATE `stat` SET `break` = '".$breaks."', `place` = '".$place."', `kills` = '".$kills."', `deaths` = '".$deaths."', `joins` = '".$joins."', `messages` = '".$message."' WHERE `nickname` = '".$username."'");
		}
	}
}