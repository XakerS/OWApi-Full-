<?php

namespace ow;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\Item;
use pocketmine\level\particle\FlameParticle;
use pocketmine\level\particle\DustParticle;
use pocketmine\level\particle\HeartParticle;
use pocketmine\level\particle\LavaParticle;
use pocketmine\level\particle\PortalParticle;
use pocketmine\level\sound\ClickSound;
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\level\sound\BatSound;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\tile\Sign;
use pocketmine\utils\TextFormat;
use pocketmine\utils\TextFormat as F;
use pocketmine\level\particle\AngryVillagerParticle;
use pocketmine\level\particle\WaterDripParticle;
use pocketmine\entity\Effect;
use pocketmine\block\Block;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\level\particle\ExplodeParticle;
use pocketmine\utils\Config;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\ItemBreakParticle;
use pocketmine\event\entity\EntityRegainHealthEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerToggleSprintEvent;

class owtop extends PluginBase implements Listener {
	private $mysqli;
	public $killsText;
	public $deathsText;
	public $breakText;
	public $placeText;
	public $joinsText;
	public $messagesText;
	
	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->mysqli = new \mysqli("127.0.0.1", "юзер", "пароль", "бд");
		$this->cord['kills'] = new Vector3(-22.7, 73, -265.5);
		$this->cord['deaths'] = new Vector3(-22.7, 73, -270.5);
		$this->cord['break'] = new Vector3(-22.7, 73, -275.5);
		$this->cord['place'] = new Vector3(-22.7, 73, -280.5);
		$this->cord['joins'] = new Vector3(-22.7, 73, -285.5);
		$this->cord['messages'] = new Vector3(-22.7, 73, -290.5);
		$this->killsText = $this->getKillsText();
		$this->breakText = $this->getBreakText();
		$this->placeText = $this->getPlaceText();
		$this->deathsText = $this->getDeathsText();
		$this->joinsText = $this->getJoinsText();
		$this->messagesText = $this->getMessagesText();
	}
	
	public function onJoin(PlayerJoinEvent $e) {
		$p = $e->getPlayer();
		$this->addParticle($p, $this->killsText, $this->cord['kills']);
		$this->addParticle($p, $this->deathsText, $this->cord['deaths']);
		$this->addParticle($p, $this->breakText, $this->cord['break']);
		$this->addParticle($p, $this->placeText, $this->cord['place']);
		$this->addParticle($p, $this->joinsText, $this->cord['joins']);
		$this->addParticle($p, $this->messagesText, $this->cord['messages']);
	}
	
	public function addParticle($player, $text, $cord) {
		$level = $this->getServer()->getDefaultLevel();
		$particle = new FloatingTextParticle($cord, $text);
		$level->addParticle($particle, [$player]);
	}
	
	public function getBreak() {
		$result = $this->mysqli->query("SELECT * FROM `stat` ORDER BY `break` DESC");
		$array = array();
		for($i = 0; $i < 5; $i++) {
			$data = $result->fetch_assoc();
			$arr = array();
			$arr['nickname'] = $data['nickname'];
			$arr['count'] = $data['break'];
			array_push($array, $arr);
		}
		$result->free();
		return $array;
	}
	
	public function getPlace() {
		$result = $this->mysqli->query("SELECT * FROM `stat` ORDER BY `place` DESC");
		$array = array();
		for($i = 0; $i < 5; $i++) {
			$data = $result->fetch_assoc();
			$arr = array();
			$arr['nickname'] = $data['nickname'];
			$arr['count'] = $data['place'];
			array_push($array, $arr);
		}
		$result->free();
		return $array;
	}
	
	public function getKills() {
		$result = $this->mysqli->query("SELECT * FROM `stat` ORDER BY `kills` DESC");
		$array = array();
		for($i = 0; $i < 5; $i++) {
			$data = $result->fetch_assoc();
			$arr = array();
			$arr['nickname'] = $data['nickname'];
			$arr['count'] = $data['kills'];
			array_push($array, $arr);
		}
		$result->free();
		return $array;
	}
	
	public function getDeaths() {
		$result = $this->mysqli->query("SELECT * FROM `stat` ORDER BY `deaths` DESC");
		$array = array();
		for($i = 0; $i < 5; $i++) {
			$data = $result->fetch_assoc();
			$arr = array();
			$arr['nickname'] = $data['nickname'];
			$arr['count'] = $data['deaths'];
			array_push($array, $arr);
		}
		$result->free();
		return $array;
	}
	
	public function getJoins() {
		$result = $this->mysqli->query("SELECT * FROM `stat` ORDER BY `joins` DESC");
		$array = array();
		for($i = 0; $i < 5; $i++) {
			$data = $result->fetch_assoc();
			$arr = array();
			$arr['nickname'] = $data['nickname'];
			$arr['count'] = $data['joins'];
			array_push($array, $arr);
		}
		$result->free();
		return $array;
	}
	
	public function getMessages() {
		$result = $this->mysqli->query("SELECT * FROM `stat` ORDER BY `messages` DESC");
		$array = array();
		for($i = 0; $i < 5; $i++) {
			$data = $result->fetch_assoc();
			$arr = array();
			$arr['nickname'] = $data['nickname'];
			$arr['count'] = $data['messages'];
			array_push($array, $arr);
		}
		$result->free();
		return $array;
	}
	
	public function getBreakText() {
		$b = $this->getBreak();
		
		$s[0] = F::GOLD. "Топ разрушителей блоков";
		$s[1] = F::RED. "№1 " .F::YELLOW. $b[0]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[0]['count']. F::GOLD. " блоков.";
		$s[2] = F::RED. "№2 " .F::YELLOW. $b[1]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[1]['count']. F::GOLD. " блоков.";
		$s[3] = F::YELLOW. "№3 " .F::YELLOW. $b[2]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[2]['count']. F::GOLD. " блоков.";
		$s[4] = F::DARK_BLUE. "№4 " .F::YELLOW. $b[3]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[3]['count']. F::GOLD. " блоков.";
		$s[5] = F::BLUE. "№5 " .F::YELLOW. $b[4]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[4]['count']. F::GOLD. " блоков.";
		
		$text = "$s[0]\n$s[1]\n$s[2]\n$s[3]\n$s[4]\n$s[5]\n";
		return $text;
	}
	
	public function getPlaceText() {
		$b = $this->getPlace();
		
		$s[0] = F::GOLD. "Топ строителей блоками";
		$s[1] = F::RED. "№1 " .F::YELLOW. $b[0]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[0]['count']. F::GOLD. " блоков.";
		$s[2] = F::RED. "№2 " .F::YELLOW. $b[1]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[1]['count']. F::GOLD. " блоков.";
		$s[3] = F::YELLOW. "№3 " .F::YELLOW. $b[2]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[2]['count']. F::GOLD. " блоков.";
		$s[4] = F::DARK_BLUE. "№4 " .F::YELLOW. $b[3]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[3]['count']. F::GOLD. " блоков.";
		$s[5] = F::BLUE. "№5 " .F::YELLOW. $b[4]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[4]['count']. F::GOLD. " блоков.";
		
		$text = "$s[0]\n$s[1]\n$s[2]\n$s[3]\n$s[4]\n$s[5]\n";
		return $text;
	}
	
	public function getKillsText() {
		$b = $this->getKills();
		
		$s[0] = F::GOLD. "Топ убийц сервера";
		$s[1] = F::RED. "№1 " .F::YELLOW. $b[0]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[0]['count']. F::GOLD. " убийств.";
		$s[2] = F::RED. "№2 " .F::YELLOW. $b[1]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[1]['count']. F::GOLD. " убийств.";
		$s[3] = F::YELLOW. "№3 " .F::YELLOW. $b[2]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[2]['count']. F::GOLD. " убийств.";
		$s[4] = F::DARK_BLUE. "№4 " .F::YELLOW. $b[3]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[3]['count']. F::GOLD. " убийств.";
		$s[5] = F::BLUE. "№5 " .F::YELLOW. $b[4]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[4]['count']. F::GOLD. " убийств.";
		
		$text = "$s[0]\n$s[1]\n$s[2]\n$s[3]\n$s[4]\n$s[5]\n";
		return $text;
	}
	
	public function getDeathsText() {
		$b = $this->getDeaths();
		
		$s[0] = F::GOLD. "Топ суицидников сервера";
		$s[1] = F::RED. "№1 " .F::YELLOW. $b[0]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[0]['count']. F::GOLD. " смертей.";
		$s[2] = F::RED. "№2 " .F::YELLOW. $b[1]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[1]['count']. F::GOLD. " смертей.";
		$s[3] = F::YELLOW. "№3 " .F::YELLOW. $b[2]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[2]['count']. F::GOLD. " смертей.";
		$s[4] = F::DARK_BLUE. "№4 " .F::YELLOW. $b[3]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[3]['count']. F::GOLD. " смертей.";
		$s[5] = F::BLUE. "№5 " .F::YELLOW. $b[4]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[4]['count']. F::GOLD. " смертей.";
		
		$text = "$s[0]\n$s[1]\n$s[2]\n$s[3]\n$s[4]\n$s[5]\n";
		return $text;
	}
	
	public function getJoinsText() {
		$b = $this->getJoins();
		
		$s[0] = F::GOLD. "Топ посетителей сервера";
		$s[1] = F::RED. "№1 " .F::YELLOW. $b[0]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[0]['count']. F::GOLD. " посещений.";
		$s[2] = F::RED. "№2 " .F::YELLOW. $b[1]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[1]['count']. F::GOLD. " посещений.";
		$s[3] = F::YELLOW. "№3 " .F::YELLOW. $b[2]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[2]['count']. F::GOLD. " посещений.";
		$s[4] = F::DARK_BLUE. "№4 " .F::YELLOW. $b[3]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[3]['count']. F::GOLD. " посещений.";
		$s[5] = F::BLUE. "№5 " .F::YELLOW. $b[4]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[4]['count']. F::GOLD. " посещений.";
		
		$text = "$s[0]\n$s[1]\n$s[2]\n$s[3]\n$s[4]\n$s[5]\n";
		return $text;
	}
	
	public function getMessagesText() {
		$b = $this->getMessages();
		
		$s[0] = F::GOLD. "Топ общительных людей на сервере";
		$s[1] = F::RED. "№1 " .F::YELLOW. $b[0]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[0]['count']. F::GOLD. " сообщений.";
		$s[2] = F::RED. "№2 " .F::YELLOW. $b[1]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[1]['count']. F::GOLD. " сообщений.";
		$s[3] = F::YELLOW. "№3 " .F::YELLOW. $b[2]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[2]['count']. F::GOLD. " сообщений.";
		$s[4] = F::DARK_BLUE. "№4 " .F::YELLOW. $b[3]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[3]['count']. F::GOLD. " сообщений.";
		$s[5] = F::BLUE. "№5 " .F::YELLOW. $b[4]['nickname']. F::GOLD. ": " .F::LIGHT_PURPLE. $b[4]['count']. F::GOLD. " сообщений.";
		
		$text = "$s[0]\n$s[1]\n$s[2]\n$s[3]\n$s[4]\n$s[5]\n";
		return $text;
	}
	
}