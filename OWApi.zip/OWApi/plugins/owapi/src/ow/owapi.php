<?php

namespace ow;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\entity\Entity;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\tile\Sign;
use pocketmine\tile\Chest;
use pocketmine\utils\TextFormat;
use pocketmine\utils\TextFormat as F;
use pocketmine\block\Block;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\level\particle\ItemBreakParticle;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\utils\Utils;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\event\level\ChunkLoadEvent;
use pocketmine\level\generator\biome\Biome;
use pocketmine\network\protocol\AddEntityPacket;
use pocketmine\network\protocol\LevelEventPacket;
use pocketmine\event\player\PlayerPreLoginEvent;
use pocketmine\network\protocol\UpdateAttributesPacket;
use pocketmine\entity\Attribute;


class owapi extends PluginBase implements Listener {
	public $goto;
	public $timeToShotdown;
	public $report;
	public $curl;
	
	public function onEnable() {
		$this->owp = $this->getServer()->getPluginManager()->getPlugin("owperms");
		$this->owc = $this->getServer()->getPluginManager()->getPlugin("owchat");
		$this->owk = $this->getServer()->getPluginManager()->getPlugin("owkit");
		$this->owa = $this->getServer()->getPluginManager()->getPlugin("owadmin");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new apitask($this), 2600);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new light($this), 20 * 7);
		$this->getServer()->getScheduler()->scheduleRepeatingTask(new reloadtask($this), 1 * 60 * 20);
		$this->distance = 1000;
		$this->getServer()->getDefaultLevel()->setTime(0);
		$this->getServer()->getDefaultLevel()->stopTime();
		$this->makeMOTD();
		$this->owtime = 60;
		$this->timeToShotdown = 120 * 60;
	}
	
	public function reloadTime() {
		$this->timeToShotdown -= 60;
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendMessage(F::YELLOW. "[OW]". F::GOLD. " Сервер будет перезагружен через " .F::GREEN. $this->timeToShotdown / 60 . F::GOLD. " мин.");
		}
		$this->getServer()->getLogger()->info(F::YELLOW. "[OW]" .F::GOLD. " До перезагрузки сервера осталось " .F::GREEN. $this->timeToShotdown / 60 . F::GOLD. " мин.");
		
		if($this->timeToShotdown <= 1) {
			$this->getServer()->shutdown();
		}
	}
	
	public function spawnBreak(BlockBreakEvent $e) {
		$player = $e->getPlayer();
        $v = new Vector3($player->getLevel()->getSpawnLocation()->getX(),$player->getPosition()->getY(),$player->getLevel()->getSpawnLocation()->getZ());
        $r = $this->getServer()->getSpawnRadius();
		if($player instanceof Player && $player->getPosition()->distance($v) <= $r && !($player->isOp())) {
			$e->setCancelled();
			$player->sendPopup(F::YELLOW. "[OWApi]" .F::GOLD. " Запрещено ломать блоки на спавне!");
		}
	}
	
	public function spawnPlace(BlockPlaceEvent $e) {
		$player = $e->getPlayer();
        $v = new Vector3($player->getLevel()->getSpawnLocation()->getX(),$player->getPosition()->getY(),$player->getLevel()->getSpawnLocation()->getZ());
        $r = $this->getServer()->getSpawnRadius();
		if($player instanceof Player && $player->getPosition()->distance($v) <= $r && !($player->isOp())) {
			$e->setCancelled();
			$player->sendPopup(F::YELLOW. "[OWApi]" .F::GOLD. " Запрещено ставить блоки на спавне!");
		}
	}
	
	public function login(PlayerJoinEvent $e) {
		$player = $e->getPlayer();
		$group = $this->owp->getGroup($player->getName());
		$this->slotManager($player, $group);
	}
	
	public function slotManager($player, $group) {
		$br = F::RESET. "\n";
		if(count($this->getServer()->getOnlinePlayers()) >= 150) {
			if($group == "user") {
				$player->close("", F::GOLD. "Сервер заполнен." .$br. "Вы можете поиграть на нашем втором сервере." .$br. $br. $br. $br. F::DARK_AQUA. F::BOLD. "Данные: " .F::DARK_GREEN. "play.octopus-world.com:19133");
			}
		}
	}
	
	
	public function light() {
	    $arr[1] = array('x' => 114, 'y' => 70, 'z' => 111, 'yaw' => 177, 'pitch' => 80);
		$arr[2] = array('x' => 100, 'y' => 70, 'z' => 95, 'yaw' => 275, 'pitch' => 71);
		$arr[3] = array('x' => 115, 'y' => 70, 'z' => 81, 'yaw' => 352, 'pitch' => 26);
		$arr[4] = array('x' => 127, 'y' => 70, 'z' => 95, 'yaw' => 270, 'pitch' => 37);
		$arr[5] = array('x' => 114, 'y' => 71, 'z' => 95, 'yaw' => 92, 'pitch' => 90);
		
		$array = $arr[mt_rand(1, 5)];
		$x = $array['x'] + mt_rand(1, 30);
		$y = $array['y'];
		$z = $array['z'] + mt_rand(1, 30);
		$yaw = $array['yaw'];
		$pitch = $array['pitch'];
		
        $pk = new AddEntityPacket();
        $pk->type = 93;
        $pk->eid = Entity::$entityCount++;
        $pk->metadata = array();
        $pk->x = $x;
        $pk->y = $y;
        $pk->z = $z;
        $pk->speedX = 0;
        $pk->speedY = 0;
        $pk->speedZ =0;
        $pk->yaw = $yaw;
        $pk->pitch = $pitch;
           
        foreach($this->getServer()->getOnlinePlayers() as $p) {
            $p->dataPacket($pk);
        }
	}
	
	public function topJoin(PlayerJoinEvent $e) {
		$this->spawnParticle($e->getPlayer());
	}
	
	public function spawnParticle($player) {
		$group = $this->owp->getGroup($player->getName());
		$br = F::RESET. "\n";
		$text[0] = F::BLUE. F::BOLD. "  - Octopus World -";
		$text[1] = F::DARK_GREEN. "Donat: " .F::YELLOW. "pay.octopus-w.ru";
		$text[2] = F::DARK_GREEN. "BK: " .F::YELLOW. "vk.com/octopus_world";
		$text[3] = F::BLUE. F::BOLD. "   - Good Luck! -";
		
		$level = $this->getServer()->getDefaultLevel();
		
		$title = F::RESET. $text[0]. F::RESET;
		$texter = $text[1]. $br. $text[2]. $br. $text[3];
		$particle = new FloatingTextParticle(new Vector3(-25.4, 73, -253.5), $texter, $title);
		$level->addParticle($particle, [$player]);
	}
	
	public function joinMsg(PlayerJoinEvent $e) {
		$e->setJoinMessage(null);
		$player = $e->getPlayer();
        foreach($player->getLevel()->getEntities() as $es){
			if(!($es Instanceof Player or $es Instanceof Human)) {
                $es->kill();
			}
        }
	}
	
	public function quitMsg(PlayerQuitEvent $e) {
		$e->setQuitMessage(null);
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendTip(F::DARK_AQUA. $e->getPlayer()->getName(). F::GOLD. " вышел с сервера");
		}
	}
	
	public function broadcastMsg() {
		$rand = mt_rand(1, 8);
		switch($rand) {
			case 1:
			$msg = F::GOLD. " Любой донат продается на сайте: " .F::AQUA. "pay.octopus-w.ru";
			break;
			case 2:
			$msg = F::GOLD. " Вип всего 50 рублей! " .F::GREEN. "Более подробно на сайте: " .F::AQUA. "pay.octopus-w.ru";
		    break;
			case 3:
			$msg = F::GOLD. " Премиум - всего 150 рублей! " .F::GREEN. "Более подробно на сайте: " .F::AQUA. "pay.octopus-w.ru";
		    break;
			case 4:
			$msg = F::GOLD. " Админка - 300 рублей! Торопитесь! " .F::GREEN. "Более подробно на сайте: " .F::AQUA. "pay.octopus-w.ru";
		    break;
			case 5:
			$msg = F::GOLD. " Octopus Elite - 450 рублей! Море возможностей! " .F::GREEN. "Более подробно на сайте: " .F::AQUA. "pay.octopus-w.ru";
		    break;
			case 6:
			$msg = F::GOLD. " У нас есть множество серверов! Список всех серверов на сайте: " .F::GREEN. "pay.octopus-w.ru";
		    break;
			case 7:
			$msg = F::GOLD. " Лагает сервер? Поиграйте на других наших серверах! Список серверов: " .F::GREEN. "pay.octopus-w.ru";
		    break;
			case 8:
			$msg = F::GOLD. " Заходите на наш " .F::YELLOW. "TeamWar" .F::GOLD. " сервер! IP: " .F::GREEN. "play.octopus-world.com " .F::GOLD. "PORT: " .F::GREEN. "19136";
		    break;
		}
		
		foreach ($this->getServer()->getOnlinePlayers() as $p) {
			$p->sendMessage(F::YELLOW. "[OW]". F::RESET. $msg);
		}
		$this->getServer()->getLogger()->info(F::YELLOW. "[OW]". F::RESET. $msg);
	}
	
    public function makeMOTD(){
        $string = F::RED. F::BOLD. "Octopus Survival" .F::DARK_BLUE. " #1 " .F::BLUE. "Western Update!";;
		if($this->getServer()->getNetwork()->getName() != $string) {
            $this->getServer()->getNetwork()->setName($string);
            $this->getLogger()->info($string);
		}
    }
	
	public function why($entityName){
 		if(!is_file($this->getDataFolder()."players/".$entityName.".yml")){
			$this->createData($entityName);
		}
	}
	
	public function createData($entityName) {
        if(!is_file($this->getDataFolder()."players/".$entityName.".yml")){
            @mkdir($this->getDataFolder() . "players/");
		    $data = new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML);
		    $data->set("x", null);
			$data->set("y", null);
			$data->set("z", null);
		    $data->save();
		}
	}
	
	public function getHomeX($entityName) {
		$this->why($entityName);
        $sFile = (new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML))->getAll();
        return $sFile["x"];
	}
	
	public function getHomeY($entityName) {
		$this->why($entityName);
        $sFile = (new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML))->getAll();
        return $sFile["y"];
	}
	
	public function getHomeZ($entityName) {
		$this->why($entityName);
        $sFile = (new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML))->getAll();
        return $sFile["z"];
	}
	
	public function setHome($entityName, $x, $y, $z) {
		$this->why($entityName);
        $sFile = (new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML))->getAll();
        $sFile["x"] = (int) $x;
		$sFile["y"] = (int) $y;
		$sFile["z"] = (int) $z;
      	$fFile = new Config($this->getDataFolder() . "players/".$entityName.".yml", Config::YAML);
	    $fFile->setAll($sFile);
        $fFile->save();
	}
	
	public function JoinDonat(PlayerJoinEvent $e) {
		$entity = $e->getPlayer();
		$this->why($entity->getName());
		$this->gotoname[$entity->getName()] = null;
		$this->goto[$entity->getName()] = false;
		$group = $this->owp->getGroup($entity->getName());
		if($group == "vip") {
			$entity->getInventory()->setSize(70);
		} elseif($group == "premium") {
			$entity->getInventory()->setSize(120);
		} elseif($group == "owner" or $group == "elite" or $group == "god") {
			$entity->getInventory()->setSize(500);
		}
	}
	
	public function WorldBorder(PlayerMoveEvent $e) {
		$entity = $e->getPlayer();
		$v = new Vector3($entity->getLevel()->getSpawnLocation()->getX(), $entity->getPosition()->getY(), $entity->getLevel()->getSpawnLocation()->getZ());
		if($this->owp->getGroup($entity->getName()) == "user") {
			if(floor($entity->distance($v)) >= $this->distance) {
				$e->setCancelled();
				$entity->sendTip(F::YELLOW. "[OWApi]" .F::GOLD. " Бесконечный мир? Привилегия не меньше " .F::GREEN. "vip" .F::GOLD. "!");
			}
		}
	}
	
    public function WhoDamager(EntityDamageEvent $e) {
        $entity = $e->getEntity();
		$entity = $e->getEntity();
		$level = $this->getServer()->getDefaultLevel();
        if ($entity instanceof Player) {
            if ($e instanceof EntityDamageByEntityEvent) {
                $damager = $e->getDamager()->getPlayer();
                $cause = $e->getEntity()->getPlayer()->getName();
                if ($e->getDamager() instanceof Player) {
                    $v = new Vector3($entity->getLevel()->getSpawnLocation()->getX(),$entity->getPosition()->getY(),$entity->getLevel()->getSpawnLocation()->getZ());
                    $r = $this->getServer()->getSpawnRadius();
                    if(($entity instanceof Player) && ($entity->getPosition()->distance($v) <= $r)) {
						if(!($damager->isOp())) {
							$e->setCancelled();
							$damager->sendTip(F::RED. "запрещено драться на спавне!");
						}
					}
				}
			}
		}
	}
	
	public function reportMessage($msg) {
		return implode(" ", $msg);
	}
	
	public function sendReport($username, $msg) {
		$text = "Игрок с ником $username сообщает вам следующее: $msg.";
		$this->sendUserMessage(170605116, $text);
	}
	
	public function sendUserMessage($id, $message) {
		$this->go('messages.send', ['user_id' => $id, 'message' => rawurlencode($message)]);
		$array = json_decode($this->lastcurl, true);
	}
	
	public function go($method, $par) { /* Данная функция выполняет методы API Вконтакте. */
        $token = "";
		$params = '';
        foreach ($par as $key => $val) {
            $params .= $key.'='.$val.'&';
        }
		
		$this->curl('https://api.vk.com/method/' .$method. '?' .$params. 'access_token=' .$token);
	}
	
	
	public function curl($args) { /* Данная функция выполняет curl запросы. Внимание! Требуется установленный php5-curl на веб.сервере! */
		$curl = curl_init($args);
        curl_setopt($curl, CURLOPT_URL, $args);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, "a=4&b=7");
		$data = @curl_exec($curl);
		@curl_close($curlObject);
        if ($data) {
			$this->lastcurl = $data;
		} else {
			$this->lastcurl = 'Курл не отвечает.';
		}
	}
	
    public function onCommand(CommandSender $entity, Command $cmd, $label, array $args) {
		$level = $this->getServer()->getDefaultLevel();
		$x = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getX();
        $y = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getY();
        $z = $this->getServer()->getDefaultLevel()->getSafeSpawn()->getZ();
		$username = strtolower($entity->getName());
		$group = $this->owp->getGroup($entity->getName());
        switch ($cmd->getName()) {
			case report:
			if(!$this->report[$username]) {
				if(count($args) > 1) {
					$msg = $this->reportMessage($args);
					$this->sendReport($username, $msg);
					$this->report[$username] = false;
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Ваш репорт успешно отправлен.");
				} else {
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Введите текст вашего репорта.");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Вы уже использовали репорт сегодня.");
			}
			break;
            case "spawn":
			if($entity Instanceof Player) {
	            $entity->teleport(new Vector3($x, $y, $z, $level));
				$entity->sendMessage(F::GOLD. "Уважаемый " .F::DARK_AQUA. $entity->getName(). F::GOLD. ", вы успешно телепортированы на спавн.");
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Комманда вводится только от имени игрока.");
			}
			break;
			case "sethome":
			if($entity Instanceof Player) {
				$this->setHome($entity->getName(), $entity->getX(), $entity->getY(), $entity->getZ());
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Точка дома успешно установлена.");
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Комманда вводится только от имени игрока.");
			}
			break;
			case "home":
			if($entity Instanceof Player) {
				if($this->getHomeX($entity->getName()) != null && $this->getHomeY($entity->getName()) != null && $this->getHomeZ($entity->getName()) != null) {
					$entity->teleport(new Vector3($this->getHomeX($entity->getName()), $this->getHomeY($entity->getName()), $this->getHomeZ($entity->getName()), $level));
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Дом, милый дом.");
				} else {
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Вы еще не ставили точку дома.");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Комманда вводится только от имени игрока.");
			}
			break;
			case "tpall":
			if($entity Instanceof Player) {
				if($group == "owner" or $group == "god") {
					foreach ($this->getServer()->getOnlinePlayers() as $p) {
						$p->teleport(new Vector3($entity->getX(), $entity->getY(), $entity->getZ()));
						$this->getServer()->getLogger()->info(F::YELLOW. "[OWApi]" .F::GREEN. $entity->getName(). F::GOLD. " телепортировал всех в одну точку.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Нужно иметь привилегию основателя.");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Комманда вводится только от имени игрока.");
			}
			break;
			case "clear":
			if($entity Instanceof Player) {
				$entity->getInventory()->clearAll();
				$entity->sendMessage(F::GOLD. "Уважаемый " .F::DARK_AQUA. $entity->getName(). F::GOLD. ", ваш инвентарь полностью очищен.");
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Комманда вводится только от имени игрока.");
			}
			break;
			case "gm":
			if($entity Instanceof Player) {
				if($group != "user" && $group != "vip") {
					if(isset($args[0])) {
						if(is_numeric($args[0])) {
							$entity->setGamemode($args[0]);
							$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Вы успешно сменили игровой режим.");
						} else {
							$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Режим должен быть указан в цифровом формате.");
						}
					} else {
						$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Вы должны указать режим.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Нужно иметь привилегию не ниже premium.");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Комманда вводится только от имени игрока.");
			}
			break;
			case "fly":
			if($entity Instanceof Player) {
				if($group != "user") {
					if(isset($args[0])) {
						if($args[0] == "on") {
							$entity->setAllowFlight(true);
							$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Fly успешно включен.");
						}
						if($args[0] == "off") {
							$entity->setAllowFlight(false);
							$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Fly успешно отключен.");
						}
					} else {
						$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " /fly on|off.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Ваша привилегия должна быть выше простого игрока.");
				}
			}
			break;
			case "setprefix":
			if($entity Instanceof Player) {
				if($group != "user") {
					if(isset($args[0])) {
						$this->owc->setPrefix($entity->getName(), $args[0]);
						$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Вы успешно установили префикс " .F::GREEN. $args[0]) .F::GOLD. ".";
						
					} else {
						$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Укажите префикс.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Ваша привилегия должна быть выше простого игрока.");
				}
			}
			break;
			case "kit":
			if($entity Instanceof Player) {
				$this->owk->giveKit($entity);
			}
			break;
			case "sleep":
			if($group != "user") {
				$entity->sleepOn(new Vector3($entity->getX(), $entity->getY(), $entity->getZ()));
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Вы успешно легли спать!");
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Группа не меньше вип!");
			}
			break;
			case "goto":
			if(isset($args[0])) {
				if($this->getServer()->getPlayer($args[0]) Instanceof Player) {
					$this->gotoname[$entity->getName()] = $args[0];
					$this->goto[$entity->getName()] = true;
				} else {
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Этого игрока нет на сервере");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Укажите никнейм игрока.");
			}
			break;
			case "owtp":
			if($entity Instanceof Player) {
				if($group != "user") {
					if(isset($args[0])) {
						if($this->getServer()->getPlayer($args[0]) Instanceof Player) {
							$x = $this->getServer()->getPlayer($args[0])->getX();
							$y = $this->getServer()->getPlayer($args[0])->getY();
							$z = $this->getServer()->getPlayer($args[0])->getZ();
							$entity->teleport(new Vector3($x, $y, $z));
							$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Вы успешно телепортировались к игроку " .F::GREEN. $args[0]. F::GOLD. "!");
						} else {
							$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Игрок " .F::GREEN. $args[0]. F::GOLD. " не на сервере.");
						}
					} else {
						$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Введите никнейм игрока.");
					}
				} else {
					$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Нужна привилегия выше обычного игрока.");
				}
			} else {
				$entity->sendMessage(F::YELLOW. "[OWApi]" .F::GOLD. " Комманда выполняется от имени игрока.");
			}
			break;
		}
	}
	
	public function moveGoto(PlayerMoveEvent $e) {
		$entity = $e->getPlayer();
		if($this->goto[$entity->getName()]) {
			if(isset($this->gotoname[$entity->getName()])) {
				if($this->getServer()->getPlayer($this->gotoname[$entity->getName()]) Instanceof Player) {
					$entity->sendTip(F::YELLOW. "[OWApi]" .F::GOLD. " Дистанция до игрока " .F::DARK_GREEN. $this->gotoname[$entity->getName()]. F::GOLD. ": " .F::GREEN. floor($entity->distance(new Vector3($this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getX(), $this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getY(), $this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getZ()))));
				}
			}
			if(floor($entity->distance(new Vector3($this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getX(), $this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getY(), $this->getServer()->getPlayer($this->gotoname[$entity->getName()])->getZ()))) <= 10) {
				$this->goto[$entity->getName()] = false;
				$this->gotoname[$entity->getName()] = null;
			}
		}
		if($this->goto[$entity->getName()]) {
			if(!($this->getServer()->getPlayer($this->gotoname[$entity->getName()]) Instanceof Player)) {
				$this->goto[$entity->getName()] = false;
				$this->gotoname[$entity->getName()] = null;
			}
		}
	}
	
	public function cmd(PlayerCommandPreprocessEvent $e) {
		$entity = $e->getPlayer();
		$msg = $e->getMessage();
		$group = $this->owp->getGroup($entity->getName());
		if($msg{0} == "/" && $msg{1} == "h" && $msg{2} == "e" && $msg{3} == "l" && $msg{4} == "p") {
			$e->setCancelled();
			if($group == "user") {
				$entity->sendMessage(F::YELLOW. "-------------------");
				$entity->sendMessage(F::YELLOW. "- /spawn" .F::DARK_GREEN. " - телепортация на спавн");
				$entity->sendMessage(F::YELLOW. "- /sethome" .F::DARK_GREEN. " - установить точку дома");
				$entity->sendMessage(F::YELLOW. "- /home" .F::DARK_GREEN. " - телепортироваться домой");
				$entity->sendMessage(F::YELLOW. "- /kit" .F::DARK_GREEN. " - получить начальный кит");
				$entity->sendMessage(F::YELLOW. "- /ow" .F::DARK_GREEN. " - приват");
				$entity->sendMessage(F::YELLOW. "- /goto" .F::DARK_GREEN. " - найти игрока");
				$entity->sendMessage(F::YELLOW. "- /shop" .F::DARK_GREEN. " - купить предмет");
				$entity->sendMessage(F::YELLOW. "-------------------");
			} elseif($group == "vip" || $group == "premium" || $group == "youtube") {
				$entity->sendMessage(F::YELLOW. "-------------------");
				$entity->sendMessage(F::YELLOW. "- /spawn" .F::DARK_GREEN. " - телепортация на спавн");
				$entity->sendMessage(F::YELLOW. "- /sethome" .F::DARK_GREEN. " - установить точку дома");
				$entity->sendMessage(F::YELLOW. "- /home" .F::DARK_GREEN. " - телепортироваться домой");
				$entity->sendMessage(F::YELLOW. "- /setprefix" .F::DARK_GREEN. " - установить префикс");
				$entity->sendMessage(F::YELLOW. "- /fly" .F::DARK_GREEN. " - включить\отключить полет");
				$entity->sendMessage(F::YELLOW. "- /gm" .F::DARK_GREEN. " - смена игрового режима");
				$entity->sendMessage(F::YELLOW. "- /sleep" .F::DARK_GREEN. " - лечь спать");
				$entity->sendMessage(F::YELLOW. "- /kit" .F::DARK_GREEN. " - получить начальный кит");
				$entity->sendMessage(F::YELLOW. "- /ow" .F::DARK_GREEN. " - приват");
				$entity->sendMessage(F::YELLOW. "- /goto" .F::DARK_GREEN. " - найти игрока");
				$entity->sendMessage(F::YELLOW. "- /shop" .F::DARK_GREEN. " - купить предмет");
				$entity->sendMessage(F::YELLOW. "-------------------");
			} elseif($group == "helper" || $group == "admin" || $group == "owner" || $group == "elite" || $group == "god") {
				$entity->sendMessage(F::YELLOW. "-------------------");
				$entity->sendMessage(F::YELLOW. "- /spawn" .F::DARK_GREEN. " - телепортация на спавн");
				$entity->sendMessage(F::YELLOW. "- /sethome" .F::DARK_GREEN. " - установить точку дома");
				$entity->sendMessage(F::YELLOW. "- /home" .F::DARK_GREEN. " - телепортироваться домой");
				$entity->sendMessage(F::YELLOW. "- /setprefix" .F::DARK_GREEN. " - установить префикс");
				$entity->sendMessage(F::YELLOW. "- /fly" .F::DARK_GREEN. " - включить\отключить полет");
				$entity->sendMessage(F::YELLOW. "- /gm" .F::DARK_GREEN. " - смена игрового режима");
				$entity->sendMessage(F::YELLOW. "- /sleep" .F::DARK_GREEN. " - лечь спать");
				$entity->sendMessage(F::YELLOW. "- /kit" .F::DARK_GREEN. " - получить начальный кит");
				$entity->sendMessage(F::YELLOW. "- /ow" .F::DARK_GREEN. " - приват");
				$entity->sendMessage(F::YELLOW. "- /owban" .F::DARK_GREEN. " - забанить игрока");
				$entity->sendMessage(F::YELLOW. "- /owkick" .F::DARK_GREEN. " - кикнуть игрока");
				$entity->sendMessage(F::YELLOW. "- /tpall" .F::DARK_GREEN. " - телепортировать всех к себе");
				$entity->sendMessage(F::YELLOW. "- /goto" .F::DARK_GREEN. " - найти игрока");
				$entity->sendMessage(F::YELLOW. "- /shop" .F::DARK_GREEN. " - купить предмет");
				$entity->sendMessage(F::YELLOW. "-------------------");
			}
		}
		if($msg{0} == "/" && $msg{1} == "m" && $msg{2} == "e") {
			$e->setCancelled();
			$entity->sendMessage(F::YELLOW. "Тут такое не пройдет :)");
		}
	}
	
}